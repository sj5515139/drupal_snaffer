(function ($) {
    "use strict";
    Drupal.behaviors.dexp_layerslider_global_settings = {
        attach: function(){
            //alert('ok');
        }
    };
})(jQuery)
