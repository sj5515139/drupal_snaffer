<div<?php print $attributes;?>>
  <?php if(isset($content)):?>
    <?php print $content; ?>
  <?php endif;?>
</div>
